/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

/**
 *
 * @author Fujitsu
 */
public class MyFrame extends javax.swing.JFrame {
    public boolean adaCommand = false;
    
    public String type;
    public String paramString;
    public int[] paramInt = new int[2];
    
    
    
    public void printRoomList(String[] args)
    {
        
    }
    
    public void printLog(String[] args)
    {
        
    }
    
    public void drawCoordinate(int x, int y, int virtualId)
    {
        
    }
    
    /**
     * Pass room ID to GUI
     * @param roomId 
     */
    public void joinRoom(int roomId)
    {
        
    }
    
    public void sendPlayerData(String name, int virtualId) {
        
    }
}
