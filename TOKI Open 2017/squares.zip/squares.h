#ifndef __SQUARES_H__
#define __SQUARES_H__

#include <vector>

long long getTotalArea(int N, std::vector<int> X, std::vector<int> Y);

#endif
