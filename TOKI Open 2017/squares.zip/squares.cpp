#include "squares.h"

#include <vector>

long long getTotalArea(int N, std::vector<int> X, std::vector<int> Y) {
  return 0;
}
