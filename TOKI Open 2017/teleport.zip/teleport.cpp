#include "teleport.h"

#include <vector>

long long getMaximumPoints(int R, int C, int K,
    std::vector<std::vector<int> > T, std::vector<std::vector<int> > P) {
  return 0;
}
