#ifndef __TELEPORT_H__
#define __TELEPORT_H__

#include <vector>

long long getMaximumPoints(int R, int C, int K,
    std::vector<std::vector<int> > T, std::vector<std::vector<int> > P);

#endif
