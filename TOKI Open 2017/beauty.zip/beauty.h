#ifndef __BEAUTY_H__
#define __BEAUTY_H__

#include <vector>

std::vector<int> getMaximumBeauty(int N, int M, int Q, std::vector<int> T,
    std::vector<int> U, std::vector<int> V,
    std::vector<int> A, std::vector<int> B);

#endif
