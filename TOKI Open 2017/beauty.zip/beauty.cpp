#include "beauty.h"

#include <vector>

std::vector<int> getMaximumBeauty(int N, int M, int Q, std::vector<int> T,
    std::vector<int> U, std::vector<int> V,
    std::vector<int> A, std::vector<int> B) {
  std::vector<int> ans;
  return ans;
}
