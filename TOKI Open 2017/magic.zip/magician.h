#ifndef __MAGICIAN_H__
#define __MAGICIAN_H__

#include <vector>

void initMagician(int N, int K);
std::vector<int> findOriginalCards(std::vector<int> cards);

#endif
