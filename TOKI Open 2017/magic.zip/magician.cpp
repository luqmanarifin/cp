#include "magician.h"

#include <vector>

void initMagician(int N, int K) {
  
}

std::vector<int> findOriginalCards(std::vector<int> cards) {
  return cards;
}
