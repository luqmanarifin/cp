#include "assistant.h"

#include <vector>

void initAssistant(int N, int K) {
  
}

int giveClue(std::vector<int> cards) {
  return 0;
}
