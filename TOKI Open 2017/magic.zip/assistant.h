#ifndef __ASSISTANT_H__
#define __ASSISTANT_H__

#include <vector>

void initAssistant(int N, int K);
int giveClue(std::vector<int> cards);

#endif
